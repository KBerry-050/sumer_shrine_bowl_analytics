"""
Player Explorer Page
Filterable and sortable player data table.
"""

import streamlit as st
import pandas as pd
import numpy as np
import sys
sys.path.append('.')
from utils.data_loader import load_data, get_tier_color, get_display_name, METRIC_GROUPS

# Load data
df = load_data()

# Header
st.markdown("""
<div class="main-header">
    <h1>🔍 Player Explorer</h1>
    <p>Filter, sort, and explore player data</p>
</div>
""", unsafe_allow_html=True)

# Filters
st.subheader("Filters")

col1, col2, col3, col4 = st.columns(4)

with col1:
    positions = st.multiselect(
        "Position",
        options=df['Position'].unique().tolist(),
        default=df['Position'].unique().tolist()
    )

with col2:
    tiers = st.multiselect(
        "Tier",
        options=df['tier'].unique().tolist(),
        default=df['tier'].unique().tolist()
    )

with col3:
    min_snaps = st.number_input(
        "Min NFL Snaps",
        min_value=0,
        max_value=int(df['nfl_total_snaps'].max()) if df['nfl_total_snaps'].notna().any() else 1000,
        value=0,
        step=50
    )

with col4:
    include_na_snaps = st.checkbox("Include players without snap data", value=True)

# Apply filters
filtered_df = df.copy()
filtered_df = filtered_df[filtered_df['Position'].isin(positions)]
filtered_df = filtered_df[filtered_df['tier'].isin(tiers)]

if min_snaps > 0:
    if include_na_snaps:
        filtered_df = filtered_df[(filtered_df['nfl_total_snaps'] >= min_snaps) | (filtered_df['nfl_total_snaps'].isna())]
    else:
        filtered_df = filtered_df[filtered_df['nfl_total_snaps'] >= min_snaps]
elif not include_na_snaps:
    filtered_df = filtered_df[filtered_df['nfl_total_snaps'].notna()]

st.markdown(f"**Showing {len(filtered_df)} of {len(df)} players**")

st.markdown("---")

# Column selector
st.subheader("Select Columns to Display")

col1, col2 = st.columns([1, 3])

with col1:
    metric_group = st.selectbox(
        "Quick Select Group",
        options=["Custom"] + list(METRIC_GROUPS.keys())
    )

# Default columns
default_cols = ['Player', 'Position', 'School', 'tier', 'production_score', 
                'nfl_total_snaps', 'game_speed_score', 'practice_speed_score']

if metric_group != "Custom":
    selected_metrics = ['Player', 'Position', 'tier'] + METRIC_GROUPS[metric_group]
else:
    # All available numeric columns for selection
    all_metrics = [col for col in df.columns if col not in ['headshot_url', 'draft_club', 'gsis_player_id', 
                                                             'first_name_CHECK', 'last_name_CHECK', 'college_gsis_id_CHECK',
                                                             'player_id', 'player_name', 'strengths']]
    
    with col2:
        selected_metrics = st.multiselect(
            "Columns",
            options=all_metrics,
            default=default_cols
        )

# Ensure we have columns selected
if not selected_metrics:
    selected_metrics = default_cols

# Filter to available columns
available_cols = [c for c in selected_metrics if c in filtered_df.columns]

st.markdown("---")

# Sorting
st.subheader("Sort Options")

sort_col1, sort_col2 = st.columns(2)

with sort_col1:
    sort_by = st.selectbox(
        "Sort by",
        options=available_cols,
        index=available_cols.index('production_score') if 'production_score' in available_cols else 0
    )

with sort_col2:
    sort_order = st.radio(
        "Order",
        options=["Descending", "Ascending"],
        horizontal=True
    )

# Sort the dataframe
ascending = sort_order == "Ascending"
display_df = filtered_df[available_cols].sort_values(
    by=sort_by, 
    ascending=ascending,
    na_position='last'
).reset_index(drop=True)

st.markdown("---")

# Display table
st.subheader("Player Data")

# Format the display
def format_cell(val, col):
    if pd.isna(val):
        return "—"
    if isinstance(val, float):
        if 'pct' in col or 'score' in col.lower():
            return f"{val:.1f}"
        elif 'speed' in col.lower() or 'acceleration' in col.lower():
            return f"{val:.2f}"
        else:
            return f"{val:.1f}"
    return val

# Create styled dataframe
styled_df = display_df.copy()

# Rename columns for display
col_rename = {col: get_display_name(col) for col in styled_df.columns}
styled_df = styled_df.rename(columns=col_rename)

# Display with formatting
st.dataframe(
    styled_df,
    use_container_width=True,
    hide_index=True,
    height=500
)

st.markdown("---")

# Summary statistics
st.subheader("📊 Summary Statistics")

numeric_cols = [c for c in available_cols if c in filtered_df.select_dtypes(include=[np.number]).columns]

if numeric_cols:
    summary_cols = st.multiselect(
        "Select metrics for summary",
        options=numeric_cols,
        default=numeric_cols[:5] if len(numeric_cols) > 5 else numeric_cols
    )
    
    if summary_cols:
        summary_df = filtered_df[summary_cols].describe().round(2)
        summary_df.index = ['Count', 'Mean', 'Std', 'Min', '25%', '50%', '75%', 'Max']
        
        # Rename columns
        summary_df.columns = [get_display_name(c) for c in summary_df.columns]
        
        st.dataframe(summary_df, use_container_width=True)

st.markdown("---")

# Export option
st.subheader("📥 Export Data")

col1, col2 = st.columns(2)

with col1:
    csv = filtered_df[available_cols].to_csv(index=False)
    st.download_button(
        label="Download as CSV",
        data=csv,
        file_name="secondary_2024_filtered.csv",
        mime="text/csv"
    )

with col2:
    st.markdown(f"""
    <div style="background: #F3F4F6; padding: 1rem; border-radius: 8px; font-size: 0.9rem;">
        <strong>Current Selection:</strong><br>
        {len(filtered_df)} players • {len(available_cols)} columns
    </div>
    """, unsafe_allow_html=True)
