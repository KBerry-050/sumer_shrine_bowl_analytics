"""
Practice vs Game Analysis Page
Compare practice and game performance metrics.
"""

import streamlit as st
import pandas as pd
import numpy as np
from scipy import stats
import sys
sys.path.append('.')
from utils.data_loader import load_data, get_tier_color, get_display_name
from utils.charts import create_practice_vs_game_chart, NFL_BLUE, NFL_RED, TIER_COLORS

# Load data
df = load_data()

# Header
st.markdown("""
<div class="main-header">
    <h1>🔄 Practice vs Game</h1>
    <p>Who performs better in practice vs games?</p>
</div>
""", unsafe_allow_html=True)

# Key insight
st.markdown("""
<div style="background: #EFF6FF; border-left: 4px solid #3B82F6; padding: 1rem; border-radius: 0 8px 8px 0; margin-bottom: 1.5rem;">
    <strong>Analysis Focus:</strong> Comparing athlete performance metrics between practice sessions and actual NFL games 
    can reveal who elevates their game under pressure and who may struggle to translate practice performance.
</div>
""", unsafe_allow_html=True)

# Metric selector
st.subheader("Select Metric to Compare")

metric_options = {
    'Max Speed (MPH)': 'speed_mph',
    'Max Acceleration': 'acceleration', 
    'Speed Score': 'speed',
    'Burst Score': 'burst',
    'Explosive Score': 'explosive'
}

selected_metric = st.selectbox(
    "Metric",
    options=list(metric_options.keys()),
    index=0
)

metric_key = metric_options[selected_metric]

# Determine column names based on selection
if metric_key == 'speed_mph':
    practice_col = 'practice_max_speed_mph'
    game_col = 'game_max_speed_mph'
elif metric_key == 'acceleration':
    practice_col = 'practice_max_acceleration'
    game_col = 'game_max_acceleration'
else:
    practice_col = f'practice_{metric_key}_score'
    game_col = f'game_{metric_key}_score'

# Create the scatter plot
fig, plot_df = create_practice_vs_game_chart(df, metric_key)

if fig:
    st.plotly_chart(fig, use_container_width=True)
    
    st.markdown("---")
    
    # Calculate differences
    plot_df['diff'] = plot_df[practice_col] - plot_df[game_col]
    plot_df['pct_diff'] = (plot_df['diff'] / plot_df[game_col]) * 100
    
    # Summary stats
    st.subheader("📊 Summary Statistics")
    
    col1, col2, col3 = st.columns(3)
    
    avg_practice = plot_df[practice_col].mean()
    avg_game = plot_df[game_col].mean()
    avg_diff = plot_df['diff'].mean()
    
    with col1:
        st.markdown(f"""
        <div style="background: white; padding: 1rem; border-radius: 8px; text-align: center;
                    box-shadow: 0 2px 4px rgba(0,0,0,0.05); border-top: 4px solid #059669;">
            <div style="font-size: 0.85rem; color: #6B7280;">Avg Practice</div>
            <div style="font-size: 1.75rem; font-weight: 700; color: #059669;">{avg_practice:.2f}</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        st.markdown(f"""
        <div style="background: white; padding: 1rem; border-radius: 8px; text-align: center;
                    box-shadow: 0 2px 4px rgba(0,0,0,0.05); border-top: 4px solid {NFL_BLUE};">
            <div style="font-size: 0.85rem; color: #6B7280;">Avg Game</div>
            <div style="font-size: 1.75rem; font-weight: 700; color: {NFL_BLUE};">{avg_game:.2f}</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col3:
        diff_color = '#059669' if avg_diff > 0 else '#DC2626'
        diff_label = "Practice Higher" if avg_diff > 0 else "Game Higher"
        st.markdown(f"""
        <div style="background: white; padding: 1rem; border-radius: 8px; text-align: center;
                    box-shadow: 0 2px 4px rgba(0,0,0,0.05); border-top: 4px solid {diff_color};">
            <div style="font-size: 0.85rem; color: #6B7280;">Avg Difference</div>
            <div style="font-size: 1.75rem; font-weight: 700; color: {diff_color};">{avg_diff:+.2f}</div>
            <div style="font-size: 0.75rem; color: #6B7280;">{diff_label}</div>
        </div>
        """, unsafe_allow_html=True)
    
    st.markdown("---")
    
    # Player breakdown tables
    st.subheader("🏆 Player Breakdown")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("**🎮 Better in Games** (Below the line)")
        st.markdown("*These players elevate their performance in game situations*")
        
        game_better = plot_df[plot_df['diff'] < 0].sort_values('diff')[['Player', 'Position', 'tier', practice_col, game_col, 'diff']].head(10)
        
        if len(game_better) > 0:
            display_game = game_better.copy()
            display_game.columns = ['Player', 'Pos', 'Tier', 'Practice', 'Game', 'Diff']
            display_game['Diff'] = display_game['Diff'].apply(lambda x: f"{x:+.2f}")
            display_game['Practice'] = display_game['Practice'].apply(lambda x: f"{x:.2f}")
            display_game['Game'] = display_game['Game'].apply(lambda x: f"{x:.2f}")
            st.dataframe(display_game, use_container_width=True, hide_index=True)
        else:
            st.markdown("*No players performed better in games for this metric*")
    
    with col2:
        st.markdown("**💪 Better in Practice** (Above the line)")
        st.markdown("*These players show higher metrics in practice settings*")
        
        practice_better = plot_df[plot_df['diff'] > 0].sort_values('diff', ascending=False)[['Player', 'Position', 'tier', practice_col, game_col, 'diff']].head(10)
        
        if len(practice_better) > 0:
            display_practice = practice_better.copy()
            display_practice.columns = ['Player', 'Pos', 'Tier', 'Practice', 'Game', 'Diff']
            display_practice['Diff'] = display_practice['Diff'].apply(lambda x: f"{x:+.2f}")
            display_practice['Practice'] = display_practice['Practice'].apply(lambda x: f"{x:.2f}")
            display_practice['Game'] = display_practice['Game'].apply(lambda x: f"{x:.2f}")
            st.dataframe(display_practice, use_container_width=True, hide_index=True)
        else:
            st.markdown("*No players performed better in practice for this metric*")
    
    st.markdown("---")
    
    # Correlation with production
    st.subheader("📈 Does Practice-to-Game Difference Predict Production?")
    
    # Merge difference with production score
    analysis_df = plot_df[['Player', 'diff']].merge(
        df[['Player', 'production_score', 'tier']], 
        on='Player'
    ).dropna()
    
    if len(analysis_df) >= 5:
        corr, p_val = stats.spearmanr(analysis_df['diff'], analysis_df['production_score'])
        
        col1, col2 = st.columns([1, 2])
        
        with col1:
            sig = "✓ Significant" if p_val < 0.05 else "✗ Not Significant"
            sig_color = '#059669' if p_val < 0.05 else '#6B7280'
            
            st.markdown(f"""
            <div style="background: white; padding: 1.25rem; border-radius: 8px;
                        box-shadow: 0 2px 4px rgba(0,0,0,0.05);">
                <div style="font-size: 0.9rem; color: #6B7280; margin-bottom: 0.5rem;">
                    Correlation: Practice-Game Diff vs Production Score
                </div>
                <div style="font-size: 2rem; font-weight: 700; color: {NFL_BLUE};">
                    r = {corr:.3f}
                </div>
                <div style="font-size: 0.85rem; color: {sig_color};">
                    p = {p_val:.4f} ({sig})
                </div>
            </div>
            """, unsafe_allow_html=True)
        
        with col2:
            if corr > 0.3:
                interpretation = """
                <strong>Players who perform better in practice tend to have higher production scores.</strong>
                This could suggest that practice performance is a valid indicator of NFL potential, 
                or that the best players consistently perform well in all settings.
                """
                bg_color = "#ECFDF5"
                border_color = "#059669"
            elif corr < -0.3:
                interpretation = """
                <strong>Players who elevate in games tend to have higher production scores.</strong>
                This suggests that "clutch" performance or game-day mentality may be more predictive 
                of NFL success than raw practice metrics.
                """
                bg_color = "#EFF6FF"
                border_color = "#3B82F6"
            else:
                interpretation = """
                <strong>No strong relationship between practice-game difference and production.</strong>
                Both "practice players" and "game-day performers" can succeed at the NFL level.
                Other factors likely play a larger role in rookie production.
                """
                bg_color = "#F3F4F6"
                border_color = "#6B7280"
            
            st.markdown(f"""
            <div style="background: {bg_color}; padding: 1rem; border-radius: 8px; 
                        border-left: 4px solid {border_color};">
                {interpretation}
            </div>
            """, unsafe_allow_html=True)
    else:
        st.warning("Not enough data points with both metrics to calculate correlation.")
    
    st.markdown("---")
    
    # Full data table
    st.subheader("📋 Full Data Table")
    
    full_table = plot_df[['Player', 'Position', 'tier', practice_col, game_col, 'diff', 'pct_diff']].sort_values('diff', ascending=False)
    full_table.columns = ['Player', 'Position', 'Tier', 'Practice', 'Game', 'Difference', '% Difference']
    
    st.dataframe(
        full_table.style.format({
            'Practice': '{:.2f}',
            'Game': '{:.2f}',
            'Difference': '{:+.2f}',
            '% Difference': '{:+.1f}%'
        }),
        use_container_width=True,
        hide_index=True
    )

else:
    st.warning("Not enough data to create Practice vs Game comparison for this metric.")

st.markdown("---")

# Methodology note
st.markdown("""
<div style="background: #F3F4F6; padding: 1rem; border-radius: 8px; font-size: 0.9rem;">
    <strong>📘 How to Read This Chart:</strong>
    <ul style="margin: 0.5rem 0 0 1rem; padding: 0;">
        <li>Points <strong>above the diagonal line</strong> = higher practice values (better in practice)</li>
        <li>Points <strong>below the diagonal line</strong> = higher game values (better in games)</li>
        <li>Points <strong>on the line</strong> = equal performance in both settings</li>
    </ul>
</div>
""", unsafe_allow_html=True)
