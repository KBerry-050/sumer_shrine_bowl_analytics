"""
Overview Dashboard Page
High-level view of the 2024 Secondary rookie class.
"""

import streamlit as st
import pandas as pd
import numpy as np
from scipy import stats
import sys
sys.path.append('.')
from utils.data_loader import load_data, get_tier_color, format_score, get_correlation_strength
from utils.charts import (
    create_tier_distribution_chart, 
    create_position_distribution_chart,
    create_scatter_plot,
    NFL_BLUE, NFL_RED
)

# Load data
df = load_data()

# Header
st.markdown("""
<div class="main-header">
    <h1>🏈 Secondary Evaluator</h1>
    <p>2024 NFL Rookie Defensive Back Analysis</p>
</div>
""", unsafe_allow_html=True)

# Key question
st.markdown("""
<div style="background: #FEF3C7; border-left: 4px solid #F59E0B; padding: 1rem; border-radius: 0 8px 8px 0; margin-bottom: 1.5rem;">
    <strong>Key Question:</strong> Which athletic traits correspond to on-field success as rookies in the NFL?
</div>
""", unsafe_allow_html=True)

# Top metrics row
col1, col2, col3, col4 = st.columns(4)

with col1:
    st.metric("Total Players", len(df))
    
with col2:
    elite_count = len(df[df['tier'] == 'Elite'])
    solid_count = len(df[df['tier'] == 'Solid'])
    st.metric("Elite + Solid", f"{elite_count + solid_count}", f"{elite_count} Elite, {solid_count} Solid")

with col3:
    avg_production = df['production_score'].mean()
    st.metric("Avg Production Score", f"{avg_production:.1f}" if pd.notna(avg_production) else "—")

with col4:
    with_snaps = df['nfl_total_snaps'].notna().sum()
    st.metric("Players with NFL Snaps", f"{with_snaps} / {len(df)}")

st.markdown("---")

# Distribution charts
col1, col2 = st.columns(2)

with col1:
    st.subheader("Tier Distribution")
    tier_fig = create_tier_distribution_chart(df)
    st.plotly_chart(tier_fig, use_container_width=True)

with col2:
    st.subheader("Position Breakdown")
    pos_fig = create_position_distribution_chart(df)
    st.plotly_chart(pos_fig, use_container_width=True)

st.markdown("---")

# Top performers
st.subheader("🏆 Top Performers by Production Score")

top_players = df.dropna(subset=['production_score']).nlargest(5, 'production_score')

cols = st.columns(5)
for i, (_, player) in enumerate(top_players.iterrows()):
    with cols[i]:
        tier_color = get_tier_color(player['tier'])
        st.markdown(f"""
        <div style="text-align: center; padding: 1rem; background: white; border-radius: 10px; 
                    box-shadow: 0 2px 4px rgba(0,0,0,0.05); border-top: 4px solid {tier_color};">
            <img src="{player['headshot_url']}" style="width: 80px; height: 80px; border-radius: 50%; 
                 object-fit: cover; border: 2px solid {tier_color}; margin-bottom: 0.5rem;">
            <div style="font-weight: 600; font-size: 0.95rem;">{player['Player']}</div>
            <div style="color: #6B7280; font-size: 0.8rem;">{player['Position']} • {player['School']}</div>
            <div style="font-size: 1.5rem; font-weight: 700; color: {NFL_BLUE}; margin-top: 0.5rem;">
                {player['production_score']:.1f}
            </div>
            <div style="font-size: 0.75rem; color: #6B7280;">Production Score</div>
        </div>
        """, unsafe_allow_html=True)

st.markdown("---")

# Key correlations insight
st.subheader("🔑 Key Correlations: Athletic Traits vs NFL Production")

# Calculate key correlations
correlations = []

athletic_metrics = [
    ('game_max_speed_mph', 'Game Max Speed'),
    ('game_max_acceleration', 'Game Max Acceleration'),
    ('game_burst_score', 'Game Burst Score'),
    ('practice_max_speed_mph', 'Practice Max Speed'),
    ('practice_max_acceleration', 'Practice Max Acceleration'),
    ('forty_yd_dash', '40-Yard Dash'),
    ('three_cone', '3-Cone Drill')
]

production_metrics = [
    ('production_score', 'Production Score'),
    ('coverage_pct', 'Coverage %ile'),
    ('playmaking_pct', 'Playmaking %ile'),
    ('tackling_pct', 'Tackling %ile')
]

for ath_col, ath_name in athletic_metrics:
    for prod_col, prod_name in production_metrics:
        # Get non-null pairs
        valid = df[[ath_col, prod_col]].dropna()
        if len(valid) >= 5:
            corr, p_val = stats.spearmanr(valid[ath_col], valid[prod_col])
            correlations.append({
                'Athletic Trait': ath_name,
                'NFL Metric': prod_name,
                'Correlation': corr,
                'P-Value': p_val,
                'N': len(valid)
            })

corr_df = pd.DataFrame(correlations)

# Show strongest correlations
if len(corr_df) > 0:
    st.markdown("**Strongest Positive Correlations:**")
    
    top_positive = corr_df.nlargest(3, 'Correlation')
    
    cols = st.columns(3)
    for i, (_, row) in enumerate(top_positive.iterrows()):
        strength, css_class = get_correlation_strength(row['Correlation'])
        with cols[i]:
            st.markdown(f"""
            <div style="background: #ECFDF5; padding: 1rem; border-radius: 8px; text-align: center;">
                <div style="font-size: 0.85rem; color: #6B7280;">{row['Athletic Trait']}</div>
                <div style="font-size: 0.75rem; color: #9CA3AF;">↕</div>
                <div style="font-size: 0.85rem; color: #6B7280;">{row['NFL Metric']}</div>
                <div style="font-size: 1.5rem; font-weight: 700; color: #059669; margin-top: 0.5rem;">
                    r = {row['Correlation']:.2f}
                </div>
                <div style="font-size: 0.75rem; color: #6B7280;">{strength} (n={row['N']})</div>
            </div>
            """, unsafe_allow_html=True)
    
    st.markdown("")
    st.markdown("**Strongest Negative Correlations:**")
    
    top_negative = corr_df.nsmallest(3, 'Correlation')
    
    cols = st.columns(3)
    for i, (_, row) in enumerate(top_negative.iterrows()):
        strength, css_class = get_correlation_strength(row['Correlation'])
        with cols[i]:
            st.markdown(f"""
            <div style="background: #FEF2F2; padding: 1rem; border-radius: 8px; text-align: center;">
                <div style="font-size: 0.85rem; color: #6B7280;">{row['Athletic Trait']}</div>
                <div style="font-size: 0.75rem; color: #9CA3AF;">↕</div>
                <div style="font-size: 0.85rem; color: #6B7280;">{row['NFL Metric']}</div>
                <div style="font-size: 1.5rem; font-weight: 700; color: #DC2626; margin-top: 0.5rem;">
                    r = {row['Correlation']:.2f}
                </div>
                <div style="font-size: 0.75rem; color: #6B7280;">{strength} (n={row['N']})</div>
            </div>
            """, unsafe_allow_html=True)

st.markdown("---")

# Quick insight
st.markdown("""
<div style="background: #EFF6FF; border-left: 4px solid #3B82F6; padding: 1rem; border-radius: 0 8px 8px 0;">
    <strong>💡 Key Insight:</strong> Navigate to the <strong>Correlations</strong> page to explore the relationship 
    between specific athletic traits and NFL production metrics. Use the <strong>Comparison</strong> tool to 
    evaluate players side-by-side.
</div>
""", unsafe_allow_html=True)
