"""
Player Comparison Page
Side-by-side player evaluation.
"""

import streamlit as st
import pandas as pd
import numpy as np
import sys
sys.path.append('.')
from utils.data_loader import load_data, get_tier_color, format_score, get_display_name
from utils.charts import create_radar_chart, create_comparison_bar_chart, NFL_BLUE, NFL_RED

# Load data
df = load_data()

# Header
st.markdown("""
<div class="main-header">
    <h1>⚖️ Player Comparison</h1>
    <p>Side-by-side player evaluation</p>
</div>
""", unsafe_allow_html=True)

# Player selection
st.subheader("Select Players to Compare")

col1, col2, col3, col4 = st.columns(4)

player_list = df['Player'].tolist()

with col1:
    player1 = st.selectbox("Player 1", player_list, index=0, key="p1")
with col2:
    player2 = st.selectbox("Player 2", player_list, index=1 if len(player_list) > 1 else 0, key="p2")
with col3:
    player3 = st.selectbox("Player 3 (Optional)", ["None"] + player_list, index=0, key="p3")
with col4:
    player4 = st.selectbox("Player 4 (Optional)", ["None"] + player_list, index=0, key="p4")

# Get selected players
selected_names = [player1, player2]
if player3 != "None":
    selected_names.append(player3)
if player4 != "None":
    selected_names.append(player4)

selected_df = df[df['Player'].isin(selected_names)]

st.markdown("---")

# Player cards row
st.subheader("Player Overview")

cols = st.columns(len(selected_names))

for i, (_, player) in enumerate(selected_df.iterrows()):
    tier_color = get_tier_color(player['tier'])
    with cols[i]:
        st.markdown(f"""
        <div style="text-align: center; padding: 1rem; background: white; border-radius: 10px; 
                    box-shadow: 0 2px 4px rgba(0,0,0,0.05); border-top: 4px solid {tier_color};">
            <img src="{player['headshot_url']}" style="width: 80px; height: 80px; border-radius: 50%; 
                 object-fit: cover; border: 2px solid {tier_color};">
            <div style="font-weight: 600; font-size: 1rem; margin-top: 0.5rem;">{player['Player']}</div>
            <div style="color: #6B7280; font-size: 0.85rem;">{player['Position']} • {player['School']}</div>
            <div style="margin-top: 0.5rem;">
                <span style="background: {tier_color}; color: {'#1a1a1a' if player['tier'] == 'Elite' else 'white'}; 
                       padding: 0.2rem 0.6rem; border-radius: 999px; font-size: 0.75rem; font-weight: 600;">
                    {player['tier']}
                </span>
            </div>
            <div style="margin-top: 0.75rem; font-size: 1.75rem; font-weight: 700; color: {NFL_BLUE};">
                {format_score(player['production_score'])}
            </div>
            <div style="font-size: 0.75rem; color: #6B7280;">Production Score</div>
        </div>
        """, unsafe_allow_html=True)

st.markdown("---")

# Comparison tabs
tab1, tab2, tab3, tab4 = st.tabs(["📊 NFL Production", "🏃 SIGA Scores", "📏 Combine", "📋 All Metrics"])

with tab1:
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("**Production Components**")
        
        # Radar chart for production
        production_metrics = ['coverage_pct', 'playmaking_pct', 'tackling_pct']
        prod_display = ['Coverage', 'Playmaking', 'Tackling']
        
        fig = create_radar_chart(selected_df, production_metrics, title="NFL Production Percentiles")
        st.plotly_chart(fig, use_container_width=True)
    
    with col2:
        st.markdown("**Production Scores**")
        
        # Bar chart comparison
        score_metrics = ['production_score', 'efficiency_score']
        fig = create_comparison_bar_chart(selected_df, score_metrics, title="Production & Efficiency Scores")
        st.plotly_chart(fig, use_container_width=True)
    
    # Detailed table
    st.markdown("**Detailed Comparison**")
    
    prod_cols = ['Player', 'tier', 'production_score', 'efficiency_score', 
                 'coverage_pct', 'playmaking_pct', 'tackling_pct', 'nfl_total_snaps']
    prod_display_df = selected_df[prod_cols].copy()
    prod_display_df.columns = ['Player', 'Tier', 'Production', 'Efficiency', 
                               'Coverage %ile', 'Playmaking %ile', 'Tackling %ile', 'NFL Snaps']
    
    st.dataframe(prod_display_df.round(1), use_container_width=True, hide_index=True)

with tab2:
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("**Game SIGA Scores**")
        
        game_metrics = ['game_speed_score', 'game_burst_score', 'game_explosive_score', 'game_agility_score']
        fig = create_radar_chart(selected_df, game_metrics, title="Game SIGA")
        st.plotly_chart(fig, use_container_width=True)
    
    with col2:
        st.markdown("**Practice SIGA Scores**")
        
        practice_metrics = ['practice_speed_score', 'practice_burst_score', 'practice_explosive_score', 'practice_agility_score']
        fig = create_radar_chart(selected_df, practice_metrics, title="Practice SIGA")
        st.plotly_chart(fig, use_container_width=True)
    
    # Combined bar chart
    st.markdown("**Game vs Practice Comparison**")
    
    all_siga = ['game_speed_score', 'practice_speed_score', 'game_burst_score', 'practice_burst_score']
    fig = create_comparison_bar_chart(selected_df, all_siga, title="Speed & Burst: Game vs Practice")
    st.plotly_chart(fig, use_container_width=True)

with tab3:
    st.markdown("**NFL Combine Measurables**")
    
    col1, col2 = st.columns(2)
    
    with col1:
        # Physical metrics
        physical_metrics = ['height', 'weight', 'arm_length', 'wingspan']
        fig = create_comparison_bar_chart(selected_df, physical_metrics, title="Physical Measurements")
        st.plotly_chart(fig, use_container_width=True)
    
    with col2:
        # Athletic metrics  
        athletic_metrics = ['forty_yd_dash', 'three_cone', 'twenty_yard_shuttle']
        fig = create_comparison_bar_chart(selected_df, athletic_metrics, title="Speed & Agility (lower is better)")
        st.plotly_chart(fig, use_container_width=True)
    
    # Explosiveness
    st.markdown("**Explosiveness**")
    explosive_metrics = ['standing_vertical', 'standing_broad_jump']
    fig = create_comparison_bar_chart(selected_df, explosive_metrics, title="Explosiveness Metrics")
    st.plotly_chart(fig, use_container_width=True)
    
    # Detailed table
    st.markdown("**Full Combine Data**")
    
    combine_cols = ['Player', 'height', 'weight', 'forty_yd_dash', 'three_cone', 
                    'twenty_yard_shuttle', 'standing_vertical', 'standing_broad_jump']
    combine_df = selected_df[combine_cols].copy()
    combine_df.columns = ['Player', 'Height (in)', 'Weight', '40-Yard', '3-Cone', 
                          '20-Shuttle', 'Vertical', 'Broad Jump']
    
    st.dataframe(combine_df.round(2), use_container_width=True, hide_index=True)

with tab4:
    st.markdown("**Complete Metrics Comparison**")
    
    # All key metrics
    all_metrics = [
        'Player', 'Position', 'tier', 
        'production_score', 'efficiency_score',
        'coverage_pct', 'playmaking_pct', 'tackling_pct',
        'nfl_total_snaps', 'nfl_games_played',
        'game_speed_score', 'game_burst_score', 'game_explosive_score', 'game_agility_score',
        'practice_speed_score', 'practice_burst_score', 'practice_explosive_score',
        'game_max_speed_mph', 'practice_max_speed_mph',
        'game_max_acceleration', 'practice_max_acceleration',
        'forty_yd_dash', 'three_cone', 'standing_vertical', 'standing_broad_jump'
    ]
    
    available_metrics = [m for m in all_metrics if m in selected_df.columns]
    
    # Transpose for easier reading
    comparison_df = selected_df[available_metrics].set_index('Player').T
    comparison_df.index = [get_display_name(idx) for idx in comparison_df.index]
    
    st.dataframe(comparison_df.round(2), use_container_width=True)

st.markdown("---")

# Key differences callout
st.subheader("📌 Key Differences")

if len(selected_names) == 2:
    p1_data = selected_df[selected_df['Player'] == selected_names[0]].iloc[0]
    p2_data = selected_df[selected_df['Player'] == selected_names[1]].iloc[0]
    
    differences = []
    
    # Production score
    if pd.notna(p1_data['production_score']) and pd.notna(p2_data['production_score']):
        diff = p1_data['production_score'] - p2_data['production_score']
        if abs(diff) > 5:
            leader = selected_names[0] if diff > 0 else selected_names[1]
            differences.append(f"**Production Score**: {leader} leads by {abs(diff):.1f} points")
    
    # Game max speed
    if pd.notna(p1_data['game_max_speed_mph']) and pd.notna(p2_data['game_max_speed_mph']):
        diff = p1_data['game_max_speed_mph'] - p2_data['game_max_speed_mph']
        if abs(diff) > 0.5:
            leader = selected_names[0] if diff > 0 else selected_names[1]
            differences.append(f"**Game Max Speed**: {leader} is {abs(diff):.1f} MPH faster")
    
    # 40-yard dash
    if pd.notna(p1_data['forty_yd_dash']) and pd.notna(p2_data['forty_yd_dash']):
        diff = p1_data['forty_yd_dash'] - p2_data['forty_yd_dash']
        if abs(diff) > 0.05:
            leader = selected_names[1] if diff > 0 else selected_names[0]  # Lower is better
            differences.append(f"**40-Yard Dash**: {leader} is {abs(diff):.2f}s faster")
    
    # NFL Snaps
    if pd.notna(p1_data['nfl_total_snaps']) and pd.notna(p2_data['nfl_total_snaps']):
        diff = p1_data['nfl_total_snaps'] - p2_data['nfl_total_snaps']
        if abs(diff) > 100:
            leader = selected_names[0] if diff > 0 else selected_names[1]
            differences.append(f"**NFL Snaps**: {leader} has {abs(int(diff))} more snaps")
    
    if differences:
        for diff in differences:
            st.markdown(f"• {diff}")
    else:
        st.markdown("*Players have similar metrics across key categories.*")
else:
    st.markdown("*Select exactly 2 players to see key differences summary.*")
