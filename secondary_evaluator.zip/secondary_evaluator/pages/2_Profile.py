"""
Player Profile Page
Deep dive on individual player data.
"""

import streamlit as st
import pandas as pd
import numpy as np
import sys
sys.path.append('.')
from utils.data_loader import load_data, get_tier_color, format_score, format_pct, get_display_name
from utils.charts import create_radar_chart, NFL_BLUE, NFL_RED, TIER_COLORS

# Load data
df = load_data()

# Header
st.markdown("""
<div class="main-header">
    <h1>👤 Player Profile</h1>
    <p>Detailed player analysis and metrics</p>
</div>
""", unsafe_allow_html=True)

# Player selector
player_list = df['Player'].tolist()
selected_player = st.selectbox("Select Player", player_list, index=0)

# Get player data
player = df[df['Player'] == selected_player].iloc[0]
tier_color = get_tier_color(player['tier'])

# Profile header
col1, col2 = st.columns([1, 3])

with col1:
    st.markdown(f"""
    <div style="text-align: center;">
        <img src="{player['headshot_url']}" style="width: 150px; height: 150px; border-radius: 50%; 
             object-fit: cover; border: 4px solid {tier_color};">
    </div>
    """, unsafe_allow_html=True)

with col2:
    tier_class = player['tier'].lower().replace(' ', '-').replace('/', '-')
    st.markdown(f"""
    <div style="padding: 0.5rem 0;">
        <h2 style="margin: 0; color: {NFL_BLUE};">{player['Player']}</h2>
        <p style="font-size: 1.1rem; color: #6B7280; margin: 0.25rem 0;">
            {player['Position']} • {player['School']} • {player['draft_club_name']}
        </p>
        <span class="tier-badge" style="background: {tier_color}; color: {'#1a1a1a' if player['tier'] == 'Elite' else 'white'};">
            {player['tier']}
        </span>
    </div>
    """, unsafe_allow_html=True)
    
    # Key metrics
    st.markdown("")
    mcol1, mcol2, mcol3, mcol4 = st.columns(4)
    with mcol1:
        st.metric("Production Score", format_score(player['production_score']))
    with mcol2:
        st.metric("NFL Snaps", f"{int(player['nfl_total_snaps']):,}" if pd.notna(player['nfl_total_snaps']) else "—")
    with mcol3:
        st.metric("Games Played", f"{int(player['nfl_games_played'])}" if pd.notna(player['nfl_games_played']) else "—")
    with mcol4:
        strengths = eval(player['strengths']) if isinstance(player['strengths'], str) else []
        st.metric("Strengths", ", ".join(strengths) if strengths else "—")

st.markdown("---")

# Tabs for different data sections
tab1, tab2, tab3, tab4, tab5 = st.tabs(["📊 NFL Production", "🏃 Game SIGA", "💪 Practice SIGA", "📏 Combine", "🎓 College"])

with tab1:
    st.subheader("NFL Rookie Production")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("**Production Components**")
        
        components = {
            'Coverage': player['coverage_pct'],
            'Playmaking': player['playmaking_pct'],
            'Tackling': player['tackling_pct']
        }
        
        for comp, val in components.items():
            if pd.notna(val):
                color = '#059669' if val >= 75 else '#3B82F6' if val >= 50 else '#6B7280'
                st.markdown(f"""
                <div style="margin-bottom: 0.75rem;">
                    <div style="display: flex; justify-content: space-between; margin-bottom: 0.25rem;">
                        <span style="font-weight: 500;">{comp}</span>
                        <span style="color: {color}; font-weight: 600;">{val:.0f}%ile</span>
                    </div>
                    <div style="background: #E5E7EB; border-radius: 4px; height: 8px; overflow: hidden;">
                        <div style="background: {color}; height: 100%; width: {val}%;"></div>
                    </div>
                </div>
                """, unsafe_allow_html=True)
            else:
                st.markdown(f"""
                <div style="margin-bottom: 0.75rem;">
                    <div style="display: flex; justify-content: space-between; margin-bottom: 0.25rem;">
                        <span style="font-weight: 500;">{comp}</span>
                        <span style="color: #9CA3AF;">No Data</span>
                    </div>
                    <div style="background: #E5E7EB; border-radius: 4px; height: 8px;"></div>
                </div>
                """, unsafe_allow_html=True)
    
    with col2:
        st.markdown("**Raw Statistics**")
        
        raw_stats = {
            'Total Snaps': player['nfl_total_snaps'],
            'Games Played': player['nfl_games_played'],
            'Coverage Snaps': player['nfl_primary_in_coverage_total'],
            'Yards Allowed': player['nfl_primary_in_coverage_yards_allowed'],
            'Interceptions': player['nfl_defense_interceptions'],
            'Pass Breakups': player['nfl_defense_pass_breakups'],
            'Tackles': player['nfl_run_defense_tackles']
        }
        
        for stat, val in raw_stats.items():
            display_val = f"{val:.0f}" if pd.notna(val) else "—"
            st.markdown(f"""
            <div style="display: flex; justify-content: space-between; padding: 0.5rem 0; 
                        border-bottom: 1px solid #E5E7EB;">
                <span style="color: #6B7280;">{stat}</span>
                <span style="font-weight: 600;">{display_val}</span>
            </div>
            """, unsafe_allow_html=True)

with tab2:
    st.subheader("Game SIGA Metrics")
    st.markdown("*Secondary In-Game Athleticism scores from NFL game tracking data*")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("**SIGA Scores (0-100)**")
        
        game_scores = {
            'Speed Score': player['game_speed_score'],
            'Burst Score': player['game_burst_score'],
            'Explosive Score': player['game_explosive_score'],
            'Agility Score': player['game_agility_score']
        }
        
        for score_name, val in game_scores.items():
            color = '#059669' if val >= 75 else '#3B82F6' if val >= 50 else '#F59E0B' if val >= 25 else '#6B7280'
            st.markdown(f"""
            <div style="margin-bottom: 0.75rem;">
                <div style="display: flex; justify-content: space-between; margin-bottom: 0.25rem;">
                    <span style="font-weight: 500;">{score_name}</span>
                    <span style="color: {color}; font-weight: 600;">{val:.1f}</span>
                </div>
                <div style="background: #E5E7EB; border-radius: 4px; height: 8px; overflow: hidden;">
                    <div style="background: {color}; height: 100%; width: {min(val, 100)}%;"></div>
                </div>
            </div>
            """, unsafe_allow_html=True)
    
    with col2:
        st.markdown("**Raw Metrics**")
        
        game_raw = {
            'Max Speed (MPH)': player['game_max_speed_mph'],
            'Avg Speed (MPH)': player['game_avg_speed_mph'],
            'Max Acceleration': player['game_max_acceleration'],
            'Avg Acceleration': player['game_avg_acceleration'],
            'Bursts per 100': player['game_bursts_per_100_frames'],
            'Agility per 100': player['game_agility_per_100_frames'],
            'Total Frames': player['game_total_frames']
        }
        
        for stat, val in game_raw.items():
            if 'Frames' in stat:
                display_val = f"{int(val):,}" if pd.notna(val) else "—"
            else:
                display_val = f"{val:.2f}" if pd.notna(val) else "—"
            st.markdown(f"""
            <div style="display: flex; justify-content: space-between; padding: 0.5rem 0; 
                        border-bottom: 1px solid #E5E7EB;">
                <span style="color: #6B7280;">{stat}</span>
                <span style="font-weight: 600;">{display_val}</span>
            </div>
            """, unsafe_allow_html=True)

with tab3:
    st.subheader("Practice SIGA Metrics")
    st.markdown("*Secondary In-Game Athleticism scores from practice tracking data*")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("**SIGA Scores (0-100)**")
        
        practice_scores = {
            'Speed Score': player['practice_speed_score'],
            'Burst Score': player['practice_burst_score'],
            'Explosive Score': player['practice_explosive_score'],
            'Agility Score': player['practice_agility_score']
        }
        
        for score_name, val in practice_scores.items():
            color = '#059669' if val >= 75 else '#3B82F6' if val >= 50 else '#F59E0B' if val >= 25 else '#6B7280'
            st.markdown(f"""
            <div style="margin-bottom: 0.75rem;">
                <div style="display: flex; justify-content: space-between; margin-bottom: 0.25rem;">
                    <span style="font-weight: 500;">{score_name}</span>
                    <span style="color: {color}; font-weight: 600;">{val:.1f}</span>
                </div>
                <div style="background: #E5E7EB; border-radius: 4px; height: 8px; overflow: hidden;">
                    <div style="background: {color}; height: 100%; width: {min(val, 100)}%;"></div>
                </div>
            </div>
            """, unsafe_allow_html=True)
    
    with col2:
        st.markdown("**Raw Metrics**")
        
        practice_raw = {
            'Max Speed (MPH)': player['practice_max_speed_mph'],
            'Avg Speed (MPH)': player['practice_avg_speed_mph'],
            'Max Acceleration': player['practice_max_acceleration'],
            'Avg Acceleration': player['practice_avg_acceleration'],
            'Bursts per 100': player['practice_bursts_per_100_frames'],
            'Total Frames': player['practice_total_frames']
        }
        
        for stat, val in practice_raw.items():
            if 'Frames' in stat:
                display_val = f"{int(val):,}" if pd.notna(val) else "—"
            else:
                display_val = f"{val:.2f}" if pd.notna(val) else "—"
            st.markdown(f"""
            <div style="display: flex; justify-content: space-between; padding: 0.5rem 0; 
                        border-bottom: 1px solid #E5E7EB;">
                <span style="color: #6B7280;">{stat}</span>
                <span style="font-weight: 600;">{display_val}</span>
            </div>
            """, unsafe_allow_html=True)

with tab4:
    st.subheader("NFL Combine Measurables")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown("**Physical**")
        physical = {
            'Height': f"{int(player['height'] // 12)}'{int(player['height'] % 12)}\"" if pd.notna(player['height']) else "—",
            'Weight': f"{int(player['weight'])} lbs" if pd.notna(player['weight']) else "—",
            'Arm Length': f"{player['arm_length']:.2f}\"" if pd.notna(player['arm_length']) else "—",
            'Wingspan': f"{player['wingspan']:.2f}\"" if pd.notna(player['wingspan']) else "—",
            'Hand Size': f"{player['hand_size']:.3f}\"" if pd.notna(player['hand_size']) else "—"
        }
        
        for stat, val in physical.items():
            st.markdown(f"""
            <div style="display: flex; justify-content: space-between; padding: 0.5rem 0; 
                        border-bottom: 1px solid #E5E7EB;">
                <span style="color: #6B7280;">{stat}</span>
                <span style="font-weight: 600;">{val}</span>
            </div>
            """, unsafe_allow_html=True)
    
    with col2:
        st.markdown("**Speed/Agility**")
        speed = {
            '40-Yard Dash': f"{player['forty_yd_dash']:.2f}s" if pd.notna(player['forty_yd_dash']) else "—",
            '10-Yard Split': f"{player['first_ten_of_forty_yd_dash']:.2f}s" if pd.notna(player['first_ten_of_forty_yd_dash']) else "—",
            '20-Yard Shuttle': f"{player['twenty_yard_shuttle']:.2f}s" if pd.notna(player['twenty_yard_shuttle']) else "—",
            '3-Cone Drill': f"{player['three_cone']:.2f}s" if pd.notna(player['three_cone']) else "—"
        }
        
        for stat, val in speed.items():
            st.markdown(f"""
            <div style="display: flex; justify-content: space-between; padding: 0.5rem 0; 
                        border-bottom: 1px solid #E5E7EB;">
                <span style="color: #6B7280;">{stat}</span>
                <span style="font-weight: 600;">{val}</span>
            </div>
            """, unsafe_allow_html=True)
    
    with col3:
        st.markdown("**Explosiveness**")
        explosive = {
            'Vertical Jump': f"{player['standing_vertical']:.1f}\"" if pd.notna(player['standing_vertical']) else "—",
            'Broad Jump': f"{int(player['standing_broad_jump'])}\"" if pd.notna(player['standing_broad_jump']) else "—",
            'Bench Press': f"{int(player['bench_reps_of_225'])} reps" if pd.notna(player['bench_reps_of_225']) else "—"
        }
        
        for stat, val in explosive.items():
            st.markdown(f"""
            <div style="display: flex; justify-content: space-between; padding: 0.5rem 0; 
                        border-bottom: 1px solid #E5E7EB;">
                <span style="color: #6B7280;">{stat}</span>
                <span style="font-weight: 600;">{val}</span>
            </div>
            """, unsafe_allow_html=True)

with tab5:
    st.subheader("College Career Statistics")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("**Background**")
        background = {
            'School': player['School'],
            'Conference': player['conference'] if pd.notna(player['conference']) else "—",
            'Recruiting Stars': f"{int(player['recruiting_stars'])} ⭐" if pd.notna(player['recruiting_stars']) else "—",
            'Hometown': f"{player['hometown']}, {player['hometown_state']}" if pd.notna(player['hometown']) else "—"
        }
        
        for stat, val in background.items():
            st.markdown(f"""
            <div style="display: flex; justify-content: space-between; padding: 0.5rem 0; 
                        border-bottom: 1px solid #E5E7EB;">
                <span style="color: #6B7280;">{stat}</span>
                <span style="font-weight: 600;">{val}</span>
            </div>
            """, unsafe_allow_html=True)
    
    with col2:
        st.markdown("**Career Stats**")
        college_stats = {
            'Interceptions': player['college_defense_interceptions_sum'],
            'Pass Breakups': player['college_defense_pass_breakups_sum'],
            'Total Tackles': player['college_defense_total_tackles_sum'],
            'Solo Tackles': player['college_defense_solo_tackles_sum'],
            'TFL': player['college_defense_tackles_for_loss_sum'],
            'Touchdowns': player['college_defense_touchdowns_sum']
        }
        
        for stat, val in college_stats.items():
            display_val = f"{int(val)}" if pd.notna(val) else "—"
            st.markdown(f"""
            <div style="display: flex; justify-content: space-between; padding: 0.5rem 0; 
                        border-bottom: 1px solid #E5E7EB;">
                <span style="color: #6B7280;">{stat}</span>
                <span style="font-weight: 600;">{display_val}</span>
            </div>
            """, unsafe_allow_html=True)

st.markdown("---")

# Draft info
st.subheader("📋 Draft Information")

draft_col1, draft_col2, draft_col3, draft_col4 = st.columns(4)

with draft_col1:
    st.metric("Draft Team", player['draft_club_name'])

with draft_col2:
    round_val = f"Round {int(player['draft_round'])}" if pd.notna(player['draft_round']) else "UDFA"
    st.metric("Round", round_val)

with draft_col3:
    pick_val = f"Pick {int(player['draft_pick'])}" if pd.notna(player['draft_pick']) else "—"
    st.metric("Pick", pick_val)

with draft_col4:
    overall_val = f"#{int(player['draft_overall_selection'])}" if pd.notna(player['draft_overall_selection']) else "—"
    st.metric("Overall", overall_val)
