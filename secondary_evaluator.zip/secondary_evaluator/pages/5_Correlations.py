"""
Correlation Analysis Page
Explore relationships between athletic traits and NFL production.
"""

import streamlit as st
import pandas as pd
import numpy as np
from scipy import stats
import sys
sys.path.append('.')
from utils.data_loader import load_data, get_display_name, get_correlation_strength, METRIC_GROUPS
from utils.charts import create_scatter_plot, NFL_BLUE, NFL_RED

# Load data
df = load_data()

# Header
st.markdown("""
<div class="main-header">
    <h1>📈 Correlation Analysis</h1>
    <p>Explore relationships between athletic traits and NFL production</p>
</div>
""", unsafe_allow_html=True)

# Key question reminder
st.markdown("""
<div style="background: #FEF3C7; border-left: 4px solid #F59E0B; padding: 1rem; border-radius: 0 8px 8px 0; margin-bottom: 1.5rem;">
    <strong>Key Question:</strong> Which athletic traits correspond to on-field success as rookies in the NFL?
</div>
""", unsafe_allow_html=True)

# Quick correlation presets
st.subheader("🎯 Featured Correlations")

preset_col1, preset_col2, preset_col3 = st.columns(3)

presets = [
    ("40-Yard Dash vs Game Max Speed", "forty_yd_dash", "game_max_speed_mph"),
    ("Game Max Speed vs Production", "game_max_speed_mph", "production_score"),
    ("Game Max Accel vs Production", "game_max_acceleration", "production_score"),
]

selected_preset = None

with preset_col1:
    if st.button("📍 40-Yard vs Game Speed", use_container_width=True):
        selected_preset = presets[0]

with preset_col2:
    if st.button("🏃 Speed vs Production", use_container_width=True):
        selected_preset = presets[1]

with preset_col3:
    if st.button("⚡ Acceleration vs Production", use_container_width=True):
        selected_preset = presets[2]

st.markdown("---")

# Custom correlation explorer
st.subheader("🔧 Custom Correlation Explorer")

col1, col2, col3 = st.columns(3)

# Build metric options
athletic_options = (
    METRIC_GROUPS['Game SIGA'] + 
    METRIC_GROUPS['Practice SIGA'] + 
    METRIC_GROUPS['Combine']
)

production_options = METRIC_GROUPS['NFL Production']

all_numeric = df.select_dtypes(include=[np.number]).columns.tolist()

with col1:
    x_axis = st.selectbox(
        "X-Axis (Athletic Trait)",
        options=athletic_options,
        format_func=get_display_name,
        index=athletic_options.index(selected_preset[1]) if selected_preset and selected_preset[1] in athletic_options else 0
    )

with col2:
    y_axis = st.selectbox(
        "Y-Axis (NFL Metric)",
        options=production_options + METRIC_GROUPS['Game SIGA'],
        format_func=get_display_name,
        index=0 if not selected_preset else (
            (production_options + METRIC_GROUPS['Game SIGA']).index(selected_preset[2]) 
            if selected_preset[2] in (production_options + METRIC_GROUPS['Game SIGA']) else 0
        )
    )

with col3:
    color_by = st.selectbox(
        "Color By",
        options=['tier', 'Position'],
        index=0
    )

# Override with preset if selected
if selected_preset:
    x_axis = selected_preset[1]
    y_axis = selected_preset[2]

# Create scatter plot
fig, corr, p_value = create_scatter_plot(
    df, x_axis, y_axis, 
    color_by=color_by,
    title=f"{get_display_name(x_axis)} vs {get_display_name(y_axis)}"
)

if fig:
    # Display correlation stats
    strength, css_class = get_correlation_strength(corr)
    
    stat_col1, stat_col2, stat_col3 = st.columns(3)
    
    with stat_col1:
        color = '#059669' if corr > 0.4 else '#DC2626' if corr < -0.4 else '#6B7280'
        st.markdown(f"""
        <div style="background: white; padding: 1rem; border-radius: 8px; text-align: center; 
                    box-shadow: 0 2px 4px rgba(0,0,0,0.05);">
            <div style="font-size: 0.85rem; color: #6B7280;">Spearman Correlation</div>
            <div style="font-size: 2rem; font-weight: 700; color: {color};">r = {corr:.3f}</div>
        </div>
        """, unsafe_allow_html=True)
    
    with stat_col2:
        sig = "✓ Significant" if p_value < 0.05 else "✗ Not Significant"
        sig_color = '#059669' if p_value < 0.05 else '#DC2626'
        st.markdown(f"""
        <div style="background: white; padding: 1rem; border-radius: 8px; text-align: center;
                    box-shadow: 0 2px 4px rgba(0,0,0,0.05);">
            <div style="font-size: 0.85rem; color: #6B7280;">P-Value</div>
            <div style="font-size: 1.5rem; font-weight: 600;">{p_value:.4f}</div>
            <div style="font-size: 0.85rem; color: {sig_color};">{sig} (α=0.05)</div>
        </div>
        """, unsafe_allow_html=True)
    
    with stat_col3:
        n_points = df[[x_axis, y_axis]].dropna().shape[0]
        st.markdown(f"""
        <div style="background: white; padding: 1rem; border-radius: 8px; text-align: center;
                    box-shadow: 0 2px 4px rgba(0,0,0,0.05);">
            <div style="font-size: 0.85rem; color: #6B7280;">Strength</div>
            <div style="font-size: 1.5rem; font-weight: 600;">{strength}</div>
            <div style="font-size: 0.85rem; color: #6B7280;">n = {n_points} players</div>
        </div>
        """, unsafe_allow_html=True)
    
    st.markdown("")
    
    # Display chart
    st.plotly_chart(fig, use_container_width=True)
    
    # Interpretation
    st.markdown("**📝 Interpretation:**")
    
    if abs(corr) >= 0.6:
        direction = "positive" if corr > 0 else "negative"
        st.markdown(f"""
        <div style="background: #ECFDF5; padding: 1rem; border-radius: 8px; border-left: 4px solid #059669;">
            <strong>Strong {direction} correlation detected.</strong> 
            {get_display_name(x_axis)} shows a meaningful relationship with {get_display_name(y_axis)}.
            {'Higher values tend to correspond with higher production.' if corr > 0 else 'Lower values tend to correspond with higher production.'}
        </div>
        """, unsafe_allow_html=True)
    elif abs(corr) >= 0.4:
        direction = "positive" if corr > 0 else "negative"
        st.markdown(f"""
        <div style="background: #FEF3C7; padding: 1rem; border-radius: 8px; border-left: 4px solid #F59E0B;">
            <strong>Moderate {direction} correlation.</strong>
            There is a noticeable trend between {get_display_name(x_axis)} and {get_display_name(y_axis)}, 
            but other factors likely play a significant role.
        </div>
        """, unsafe_allow_html=True)
    else:
        st.markdown(f"""
        <div style="background: #F3F4F6; padding: 1rem; border-radius: 8px; border-left: 4px solid #6B7280;">
            <strong>Weak or no correlation.</strong>
            {get_display_name(x_axis)} does not appear to have a strong linear relationship with {get_display_name(y_axis)} in this dataset.
        </div>
        """, unsafe_allow_html=True)

else:
    st.warning("Not enough data points to calculate correlation. Try different metrics.")

st.markdown("---")

# Correlation matrix
st.subheader("📊 Correlation Matrix: Athletic Traits vs NFL Production")

# Select metrics for matrix
matrix_athletic = ['game_max_speed_mph', 'game_max_acceleration', 'practice_max_speed_mph', 
                   'practice_max_acceleration', 'forty_yd_dash', 'three_cone']
matrix_production = ['production_score', 'coverage_pct', 'playmaking_pct', 'tackling_pct']

# Calculate correlation matrix
corr_data = []
for ath in matrix_athletic:
    row = {'Athletic Trait': get_display_name(ath)}
    for prod in matrix_production:
        valid = df[[ath, prod]].dropna()
        if len(valid) >= 5:
            corr, _ = stats.spearmanr(valid[ath], valid[prod])
            row[get_display_name(prod)] = corr
        else:
            row[get_display_name(prod)] = np.nan
    corr_data.append(row)

corr_matrix = pd.DataFrame(corr_data).set_index('Athletic Trait')

# Style the matrix
def color_correlation(val):
    if pd.isna(val):
        return 'background-color: #F3F4F6; color: #9CA3AF;'
    elif val >= 0.4:
        return 'background-color: #DCFCE7; color: #166534; font-weight: 600;'
    elif val <= -0.4:
        return 'background-color: #FEE2E2; color: #991B1B; font-weight: 600;'
    else:
        return 'background-color: #F9FAFB; color: #374151;'

styled_matrix = corr_matrix.style.applymap(color_correlation).format("{:.2f}", na_rep="—")

st.dataframe(styled_matrix, use_container_width=True)

st.markdown("""
<div style="font-size: 0.85rem; color: #6B7280; margin-top: 0.5rem;">
    <strong>Color Key:</strong> 
    <span style="background: #DCFCE7; padding: 0.2rem 0.5rem; border-radius: 4px; margin-left: 0.5rem;">Strong Positive (≥0.4)</span>
    <span style="background: #FEE2E2; padding: 0.2rem 0.5rem; border-radius: 4px; margin-left: 0.5rem;">Strong Negative (≤-0.4)</span>
    <span style="background: #F9FAFB; padding: 0.2rem 0.5rem; border-radius: 4px; margin-left: 0.5rem;">Weak</span>
</div>
""", unsafe_allow_html=True)

st.markdown("---")

# Key findings summary
st.subheader("🔑 Key Findings")

# Calculate all correlations and find strongest
all_correlations = []
for ath in matrix_athletic:
    for prod in matrix_production:
        valid = df[[ath, prod]].dropna()
        if len(valid) >= 5:
            corr, p_val = stats.spearmanr(valid[ath], valid[prod])
            all_correlations.append({
                'Athletic': get_display_name(ath),
                'Production': get_display_name(prod),
                'Correlation': corr,
                'P-Value': p_val,
                'N': len(valid)
            })

if all_correlations:
    corr_summary = pd.DataFrame(all_correlations)
    
    # Strongest positive
    strongest_pos = corr_summary.nlargest(1, 'Correlation').iloc[0]
    # Strongest negative
    strongest_neg = corr_summary.nsmallest(1, 'Correlation').iloc[0]
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown(f"""
        <div style="background: #ECFDF5; padding: 1.25rem; border-radius: 8px;">
            <div style="font-size: 0.85rem; color: #065F46; font-weight: 600; margin-bottom: 0.5rem;">
                📈 Strongest Positive Correlation
            </div>
            <div style="font-size: 1.1rem; font-weight: 600; color: #1F2937;">
                {strongest_pos['Athletic']} → {strongest_pos['Production']}
            </div>
            <div style="font-size: 1.5rem; font-weight: 700; color: #059669; margin-top: 0.5rem;">
                r = {strongest_pos['Correlation']:.3f}
            </div>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        st.markdown(f"""
        <div style="background: #FEF2F2; padding: 1.25rem; border-radius: 8px;">
            <div style="font-size: 0.85rem; color: #991B1B; font-weight: 600; margin-bottom: 0.5rem;">
                📉 Strongest Negative Correlation
            </div>
            <div style="font-size: 1.1rem; font-weight: 600; color: #1F2937;">
                {strongest_neg['Athletic']} → {strongest_neg['Production']}
            </div>
            <div style="font-size: 1.5rem; font-weight: 700; color: #DC2626; margin-top: 0.5rem;">
                r = {strongest_neg['Correlation']:.3f}
            </div>
        </div>
        """, unsafe_allow_html=True)

st.markdown("")

# Methodology note
st.markdown("""
<div style="background: #EFF6FF; padding: 1rem; border-radius: 8px; font-size: 0.9rem;">
    <strong>📘 Methodology Note:</strong> All correlations use <strong>Spearman's rank correlation</strong>, 
    which measures monotonic relationships and is robust to outliers and non-normal distributions. 
    This is preferred over Pearson correlation given our small sample size (n=26) and potential outliers.
</div>
""", unsafe_allow_html=True)
