"""
Secondary Evaluator App
NFL Rookie Defensive Back Analysis Tool

Main entry point for the Streamlit application.
"""

import streamlit as st

# Page config must be first Streamlit command
st.set_page_config(
    page_title="Secondary Evaluator",
    page_icon="🏈",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for NFL-ish styling
st.markdown("""
<style>
    /* NFL-inspired color scheme */
    :root {
        --nfl-blue: #013369;
        --nfl-red: #D50A0A;
        --nfl-white: #FFFFFF;
        --nfl-gray: #A5ACAF;
    }
    
    /* Header styling */
    .main-header {
        background: linear-gradient(135deg, #013369 0%, #014a8f 100%);
        color: white;
        padding: 1.5rem 2rem;
        border-radius: 10px;
        margin-bottom: 1.5rem;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
    
    .main-header h1 {
        margin: 0;
        font-size: 2.2rem;
        font-weight: 700;
    }
    
    .main-header p {
        margin: 0.5rem 0 0 0;
        opacity: 0.9;
        font-size: 1.1rem;
    }
    
    /* Metric card styling */
    .metric-card {
        background: white;
        border-radius: 8px;
        padding: 1rem 1.25rem;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
        border-left: 4px solid #013369;
    }
    
    .metric-card.elite {
        border-left-color: #FFD700;
    }
    
    .metric-card.solid {
        border-left-color: #3B82F6;
    }
    
    .metric-card.developmental {
        border-left-color: #6B7280;
    }
    
    /* Tier badges */
    .tier-badge {
        display: inline-block;
        padding: 0.25rem 0.75rem;
        border-radius: 999px;
        font-size: 0.85rem;
        font-weight: 600;
    }
    
    .tier-elite {
        background: linear-gradient(135deg, #FFD700 0%, #FFA500 100%);
        color: #1a1a1a;
    }
    
    .tier-solid {
        background: linear-gradient(135deg, #3B82F6 0%, #2563EB 100%);
        color: white;
    }
    
    .tier-developmental {
        background: linear-gradient(135deg, #6B7280 0%, #4B5563 100%);
        color: white;
    }
    
    .tier-na {
        background: #E5E7EB;
        color: #6B7280;
    }
    
    /* Sidebar styling */
    [data-testid="stSidebar"] {
        background: linear-gradient(180deg, #013369 0%, #001a3a 100%);
    }
    
    [data-testid="stSidebar"] .stMarkdown {
        color: white;
    }
    
    /* Player card */
    .player-card {
        background: white;
        border-radius: 12px;
        padding: 1.5rem;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.07);
        text-align: center;
        transition: transform 0.2s;
    }
    
    .player-card:hover {
        transform: translateY(-2px);
    }
    
    .player-card img {
        border-radius: 50%;
        width: 100px;
        height: 100px;
        object-fit: cover;
        border: 3px solid #013369;
    }
    
    /* Table styling */
    .dataframe {
        font-size: 0.9rem;
    }
    
    /* Correlation badge */
    .corr-strong {
        color: #059669;
        font-weight: 600;
    }
    
    .corr-moderate {
        color: #D97706;
        font-weight: 600;
    }
    
    .corr-weak {
        color: #6B7280;
    }
    
    /* Hide Streamlit branding */
    #MainMenu {visibility: hidden;}
    footer {visibility: hidden;}
</style>
""", unsafe_allow_html=True)

# Sidebar navigation
st.sidebar.markdown("""
<div style="text-align: center; padding: 1rem 0;">
    <h2 style="color: white; margin: 0;">🏈 Secondary</h2>
    <h3 style="color: #A5ACAF; margin: 0; font-weight: 400;">Evaluator</h3>
</div>
""", unsafe_allow_html=True)

st.sidebar.markdown("---")

# Navigation
page = st.sidebar.radio(
    "Navigation",
    ["📊 Overview", "👤 Player Profile", "⚖️ Comparison", "🔍 Explorer", "📈 Correlations", "🔄 Practice vs Game"],
    label_visibility="collapsed"
)

st.sidebar.markdown("---")

# Info section
st.sidebar.markdown("""
<div style="color: #A5ACAF; font-size: 0.85rem; padding: 0 0.5rem;">
    <p><strong>2024 Rookie Class</strong></p>
    <p>26 Players (15 CB, 11 SAF)</p>
    <p style="margin-top: 1rem; font-size: 0.75rem;">
        Analysis of athletic traits and NFL rookie production for defensive backs.
    </p>
</div>
""", unsafe_allow_html=True)

# Load the appropriate page
if page == "📊 Overview":
    exec(open("pages/1_Overview.py").read())
elif page == "👤 Player Profile":
    exec(open("pages/2_Profile.py").read())
elif page == "⚖️ Comparison":
    exec(open("pages/3_Comparison.py").read())
elif page == "🔍 Explorer":
    exec(open("pages/4_Explorer.py").read())
elif page == "📈 Correlations":
    exec(open("pages/5_Correlations.py").read())
elif page == "🔄 Practice vs Game":
    exec(open("pages/6_Practice_vs_Game.py").read())
