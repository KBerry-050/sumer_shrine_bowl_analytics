"""
Data Loader Utility
Loads and caches the Secondary 2024 dataset.
"""

import pandas as pd
import streamlit as st
from pathlib import Path

@st.cache_data
def load_data():
    """Load the Secondary 2024 Final dataset."""
    # Try multiple paths for flexibility
    possible_paths = [
        "data/Secondary_2024_Final.csv",
        "../data/Secondary_2024_Final.csv",
        "/mnt/user-data/uploads/Secondary_2024_Final.csv"
    ]
    
    for path in possible_paths:
        if Path(path).exists():
            df = pd.read_csv(path)
            return df
    
    # If running in Dataiku, try dataset API
    try:
        import dataiku
        df = dataiku.Dataset("Secondary_2024_Final").get_dataframe()
        return df
    except:
        pass
    
    st.error("Could not load dataset. Please ensure Secondary_2024_Final.csv is in the data/ folder.")
    return pd.DataFrame()


def get_tier_color(tier):
    """Return color for tier."""
    colors = {
        'Elite': '#FFD700',
        'Solid': '#3B82F6',
        'Developmental': '#6B7280',
        'N/A Contributor': '#E5E7EB'
    }
    return colors.get(tier, '#E5E7EB')


def get_tier_badge_class(tier):
    """Return CSS class for tier badge."""
    classes = {
        'Elite': 'tier-elite',
        'Solid': 'tier-solid',
        'Developmental': 'tier-developmental',
        'N/A Contributor': 'tier-na'
    }
    return classes.get(tier, 'tier-na')


def format_score(value, decimals=1):
    """Format a score value, handling NaN."""
    if pd.isna(value):
        return "—"
    return f"{value:.{decimals}f}"


def format_pct(value):
    """Format a percentile value."""
    if pd.isna(value):
        return "—"
    return f"{value:.0f}"


def get_correlation_strength(r):
    """Categorize correlation strength."""
    r_abs = abs(r)
    if r_abs >= 0.6:
        return "Strong", "corr-strong"
    elif r_abs >= 0.4:
        return "Moderate", "corr-moderate"
    else:
        return "Weak", "corr-weak"


# Column name mappings for display
COLUMN_DISPLAY_NAMES = {
    # NFL Production
    'production_score': 'Production Score',
    'efficiency_score': 'Efficiency Score',
    'coverage_pct': 'Coverage %ile',
    'playmaking_pct': 'Playmaking %ile',
    'tackling_pct': 'Tackling %ile',
    'nfl_total_snaps': 'NFL Snaps',
    'nfl_games_played': 'NFL Games',
    
    # Game SIGA
    'game_speed_score': 'Game Speed',
    'game_burst_score': 'Game Burst',
    'game_explosive_score': 'Game Explosive',
    'game_agility_score': 'Game Agility',
    'game_max_speed_mph': 'Game Max Speed (MPH)',
    'game_avg_speed_mph': 'Game Avg Speed (MPH)',
    'game_max_acceleration': 'Game Max Accel',
    
    # Practice SIGA
    'practice_speed_score': 'Practice Speed',
    'practice_burst_score': 'Practice Burst',
    'practice_explosive_score': 'Practice Explosive',
    'practice_agility_score': 'Practice Agility',
    'practice_max_speed_mph': 'Practice Max Speed (MPH)',
    'practice_avg_speed_mph': 'Practice Avg Speed (MPH)',
    'practice_max_acceleration': 'Practice Max Accel',
    
    # Combine
    'forty_yd_dash': '40-Yard Dash',
    'three_cone': '3-Cone Drill',
    'twenty_yard_shuttle': '20-Yard Shuttle',
    'standing_vertical': 'Vertical Jump',
    'standing_broad_jump': 'Broad Jump',
    'height': 'Height (in)',
    'weight': 'Weight (lbs)',
    'arm_length': 'Arm Length (in)',
    'wingspan': 'Wingspan (in)',
    
    # College
    'college_defense_interceptions_sum': 'College INTs',
    'college_defense_pass_breakups_sum': 'College PBUs',
    'college_defense_total_tackles_sum': 'College Tackles',
}


def get_display_name(col):
    """Get display name for a column."""
    return COLUMN_DISPLAY_NAMES.get(col, col.replace('_', ' ').title())


# Metric groups for selection
METRIC_GROUPS = {
    'NFL Production': [
        'production_score', 'efficiency_score', 'coverage_pct', 
        'playmaking_pct', 'tackling_pct', 'nfl_total_snaps'
    ],
    'Game SIGA': [
        'game_speed_score', 'game_burst_score', 'game_explosive_score',
        'game_agility_score', 'game_max_speed_mph', 'game_max_acceleration'
    ],
    'Practice SIGA': [
        'practice_speed_score', 'practice_burst_score', 'practice_explosive_score',
        'practice_max_speed_mph', 'practice_max_acceleration'
    ],
    'Combine': [
        'forty_yd_dash', 'three_cone', 'twenty_yard_shuttle',
        'standing_vertical', 'standing_broad_jump', 'height', 'weight'
    ],
    'College': [
        'college_defense_interceptions_sum', 'college_defense_pass_breakups_sum',
        'college_defense_total_tackles_sum'
    ]
}
