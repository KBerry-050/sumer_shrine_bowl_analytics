"""
Charts Utility
Reusable chart functions for the Secondary Evaluator app.
"""

import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
import numpy as np
from scipy import stats

# NFL color scheme
NFL_BLUE = '#013369'
NFL_RED = '#D50A0A'
NFL_GRAY = '#A5ACAF'
NFL_WHITE = '#FFFFFF'

TIER_COLORS = {
    'Elite': '#FFD700',
    'Solid': '#3B82F6', 
    'Developmental': '#6B7280',
    'N/A Contributor': '#D1D5DB'
}

POSITION_COLORS = {
    'CB': NFL_BLUE,
    'SAF': NFL_RED
}


def create_tier_distribution_chart(df):
    """Create a donut chart of tier distribution."""
    tier_counts = df['tier'].value_counts()
    
    fig = go.Figure(data=[go.Pie(
        labels=tier_counts.index,
        values=tier_counts.values,
        hole=0.5,
        marker_colors=[TIER_COLORS.get(t, '#E5E7EB') for t in tier_counts.index],
        textinfo='label+value',
        textposition='outside',
        textfont=dict(size=12)
    )])
    
    fig.update_layout(
        showlegend=False,
        margin=dict(t=20, b=20, l=20, r=20),
        height=300,
        annotations=[dict(
            text=f"{len(df)}<br>Players",
            x=0.5, y=0.5,
            font_size=16,
            showarrow=False
        )]
    )
    
    return fig


def create_position_distribution_chart(df):
    """Create a bar chart of position distribution."""
    pos_counts = df['Position'].value_counts()
    
    fig = go.Figure(data=[go.Bar(
        x=pos_counts.index,
        y=pos_counts.values,
        marker_color=[POSITION_COLORS.get(p, NFL_GRAY) for p in pos_counts.index],
        text=pos_counts.values,
        textposition='auto'
    )])
    
    fig.update_layout(
        xaxis_title="",
        yaxis_title="Count",
        margin=dict(t=20, b=40, l=40, r=20),
        height=250,
        showlegend=False
    )
    
    return fig


def create_radar_chart(players_df, metrics, title="Player Comparison"):
    """Create a radar chart comparing players across metrics."""
    fig = go.Figure()
    
    colors = [NFL_BLUE, NFL_RED, '#059669', '#D97706']
    
    for i, (_, player) in enumerate(players_df.iterrows()):
        values = [player[m] if pd.notna(player[m]) else 0 for m in metrics]
        values.append(values[0])  # Close the polygon
        
        fig.add_trace(go.Scatterpolar(
            r=values,
            theta=metrics + [metrics[0]],
            fill='toself',
            name=player['Player'],
            line_color=colors[i % len(colors)],
            opacity=0.7
        ))
    
    fig.update_layout(
        polar=dict(
            radialaxis=dict(
                visible=True,
                range=[0, 100]
            )
        ),
        showlegend=True,
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=-0.2,
            xanchor="center",
            x=0.5
        ),
        margin=dict(t=40, b=60, l=60, r=60),
        height=400,
        title=dict(text=title, x=0.5, font=dict(size=14))
    )
    
    return fig


def create_scatter_plot(df, x_col, y_col, color_by='tier', title=None, show_trendline=True):
    """Create a scatter plot with optional trendline and correlation."""
    # Filter to non-null values
    plot_df = df[[x_col, y_col, 'Player', 'Position', 'tier']].dropna(subset=[x_col, y_col])
    
    if len(plot_df) < 3:
        return None, None, None
    
    # Calculate Spearman correlation
    corr, p_value = stats.spearmanr(plot_df[x_col], plot_df[y_col])
    
    # Color mapping
    if color_by == 'tier':
        color_map = TIER_COLORS
    else:
        color_map = POSITION_COLORS
    
    fig = px.scatter(
        plot_df,
        x=x_col,
        y=y_col,
        color=color_by,
        color_discrete_map=color_map,
        hover_name='Player',
        hover_data={'Position': True, 'tier': True},
        title=title
    )
    
    # Add trendline
    if show_trendline and len(plot_df) >= 3:
        z = np.polyfit(plot_df[x_col], plot_df[y_col], 1)
        p = np.poly1d(z)
        x_line = np.linspace(plot_df[x_col].min(), plot_df[x_col].max(), 100)
        
        fig.add_trace(go.Scatter(
            x=x_line,
            y=p(x_line),
            mode='lines',
            name='Trendline',
            line=dict(color=NFL_GRAY, dash='dash', width=2),
            showlegend=False
        ))
    
    fig.update_layout(
        xaxis_title=x_col.replace('_', ' ').title(),
        yaxis_title=y_col.replace('_', ' ').title(),
        margin=dict(t=60, b=40, l=40, r=40),
        height=450,
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=-0.25,
            xanchor="center",
            x=0.5
        )
    )
    
    fig.update_traces(marker=dict(size=12, line=dict(width=1, color='white')))
    
    return fig, corr, p_value


def create_bar_chart(df, x_col, y_col, color_col='tier', title=None, horizontal=False):
    """Create a bar chart."""
    plot_df = df.dropna(subset=[y_col]).sort_values(y_col, ascending=horizontal)
    
    if horizontal:
        fig = px.bar(
            plot_df,
            y=x_col,
            x=y_col,
            color=color_col,
            color_discrete_map=TIER_COLORS,
            orientation='h',
            title=title
        )
    else:
        fig = px.bar(
            plot_df,
            x=x_col,
            y=y_col,
            color=color_col,
            color_discrete_map=TIER_COLORS,
            title=title
        )
    
    fig.update_layout(
        margin=dict(t=60, b=40, l=40, r=40),
        height=400,
        showlegend=True
    )
    
    return fig


def create_comparison_bar_chart(players_df, metrics, title="Metric Comparison"):
    """Create grouped bar chart for player comparison."""
    fig = go.Figure()
    
    colors = [NFL_BLUE, NFL_RED, '#059669', '#D97706']
    
    for i, (_, player) in enumerate(players_df.iterrows()):
        values = [player[m] if pd.notna(player[m]) else 0 for m in metrics]
        
        fig.add_trace(go.Bar(
            name=player['Player'],
            x=metrics,
            y=values,
            marker_color=colors[i % len(colors)]
        ))
    
    fig.update_layout(
        barmode='group',
        xaxis_title="",
        yaxis_title="Score",
        margin=dict(t=40, b=40, l=40, r=40),
        height=350,
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=-0.3,
            xanchor="center",
            x=0.5
        ),
        title=dict(text=title, x=0.5, font=dict(size=14))
    )
    
    return fig


def create_practice_vs_game_chart(df, metric_type='speed'):
    """Create scatter plot comparing practice vs game metrics."""
    if metric_type == 'speed':
        x_col = 'practice_max_speed_mph'
        y_col = 'game_max_speed_mph'
        title = "Practice vs Game: Max Speed (MPH)"
    elif metric_type == 'acceleration':
        x_col = 'practice_max_acceleration'
        y_col = 'game_max_acceleration'
        title = "Practice vs Game: Max Acceleration"
    else:  # scores
        x_col = f'practice_{metric_type}_score'
        y_col = f'game_{metric_type}_score'
        title = f"Practice vs Game: {metric_type.title()} Score"
    
    plot_df = df[['Player', 'Position', 'tier', x_col, y_col]].dropna(subset=[x_col, y_col])
    
    if len(plot_df) < 2:
        return None, None
    
    # Calculate difference (practice - game)
    plot_df['difference'] = plot_df[x_col] - plot_df[y_col]
    
    fig = px.scatter(
        plot_df,
        x=x_col,
        y=y_col,
        color='tier',
        color_discrete_map=TIER_COLORS,
        hover_name='Player',
        hover_data={'Position': True, 'difference': ':.2f'},
        title=title
    )
    
    # Add diagonal line (x=y)
    max_val = max(plot_df[x_col].max(), plot_df[y_col].max())
    min_val = min(plot_df[x_col].min(), plot_df[y_col].min())
    
    fig.add_trace(go.Scatter(
        x=[min_val, max_val],
        y=[min_val, max_val],
        mode='lines',
        name='Equal Performance',
        line=dict(color=NFL_GRAY, dash='dash', width=2),
        showlegend=True
    ))
    
    fig.update_layout(
        xaxis_title=f"Practice {metric_type.title()}",
        yaxis_title=f"Game {metric_type.title()}",
        margin=dict(t=60, b=40, l=40, r=40),
        height=450,
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=-0.25,
            xanchor="center",
            x=0.5
        )
    )
    
    fig.update_traces(marker=dict(size=12, line=dict(width=1, color='white')))
    
    # Add annotations for above/below line
    fig.add_annotation(
        x=max_val * 0.95, y=min_val + (max_val - min_val) * 0.15,
        text="Better in Practice →",
        showarrow=False,
        font=dict(size=10, color=NFL_GRAY)
    )
    
    fig.add_annotation(
        x=min_val + (max_val - min_val) * 0.05, y=max_val * 0.95,
        text="← Better in Games",
        showarrow=False,
        font=dict(size=10, color=NFL_GRAY)
    )
    
    return fig, plot_df
